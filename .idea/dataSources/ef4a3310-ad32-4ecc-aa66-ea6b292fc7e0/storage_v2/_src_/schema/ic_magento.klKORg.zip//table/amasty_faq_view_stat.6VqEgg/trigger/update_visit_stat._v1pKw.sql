create trigger update_visit_stat
  after INSERT
  on amasty_faq_view_stat
  for each row
BEGIN
UPDATE amasty_faq_category SET visit_count = visit_count + 1 WHERE category_id = NEW.category_id;UPDATE amasty_faq_question SET visit_count = visit_count + 1 WHERE question_id = NEW.question_id;
END;

