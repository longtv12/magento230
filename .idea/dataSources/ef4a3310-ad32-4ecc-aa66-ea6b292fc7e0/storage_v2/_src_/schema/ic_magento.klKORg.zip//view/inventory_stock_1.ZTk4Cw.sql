create view inventory_stock_1 as
select distinct `legacy_stock_status`.`product_id`   AS `product_id`,
                `legacy_stock_status`.`website_id`   AS `website_id`,
                `legacy_stock_status`.`stock_id`     AS `stock_id`,
                `legacy_stock_status`.`qty`          AS `quantity`,
                `legacy_stock_status`.`stock_status` AS `is_salable`,
                `product`.`sku`                      AS `sku`
from (`ic_magento`.`cataloginventory_stock_status` `legacy_stock_status`
       join `ic_magento`.`catalog_product_entity` `product`
            on ((`legacy_stock_status`.`product_id` = `product`.`entity_id`)));

